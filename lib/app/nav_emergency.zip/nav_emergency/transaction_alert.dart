import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:getx_skeleton/app/controllers/my_app_user.dart';
import 'package:getx_skeleton/app/modules/choose_plans/calendat_booking_view.dart';
import 'package:getx_skeleton/app/modules/nav_emergency/controllers/transaction_alert_controller.dart';
import 'package:timer_count_down/timer_controller.dart';
import 'package:timer_count_down/timer_count_down.dart';
import 'package:vibration/vibration.dart';

import '../../../config/theme/apptextstyles.dart';
import '../../../config/theme/custom_app_colors.dart';
import '../../../utils/men_alert_animation.dart';
import '../../../utils/size_config.dart';
import '../routes/app_pages.dart';

class SendAlertScreen extends StatefulWidget {
  const SendAlertScreen({Key? key}) : super(key: key);

  @override
  State<SendAlertScreen> createState() => _SendAlertScreenState();
}

class _SendAlertScreenState extends State<SendAlertScreen>
    with TickerProviderStateMixin {
  CountdownController? countdownController =
      CountdownController(autoStart: false);
  TransactionAlertController controller = TransactionAlertController();

  String alertType = 'ambulance';

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  @override
  Widget build(BuildContext context) {
    final MyAppUser myAppUser = Get.find<MyAppUser>();
    BoxConstraints constraints = BoxConstraints(
        maxWidth: MediaQuery.of(context).size.width,
        maxHeight: MediaQuery.of(context).size.height);
    SizeConfig().init(constraints, Orientation.portrait);
    return Scaffold(
      key: _scaffoldKey,
      // floatingActionButton: FloatingActionButton(
      //   child: const Icon(Icons.face),
      //   onPressed: () async {
      //     List<Offering> offers = await PurchasesApi.fetchOffers();
      //     print('offers.lenght: ${offers[0].availablePackages.length}');
      //   },
      // ),
      backgroundColor: Colors.white,
      drawer: const CustomDrawer(),
      body: SafeArea(
          child: Column(
        children: [
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: const EdgeInsets.only(top: 3.0, left: 10),
              child: InkWell(
                child: const Icon(Icons.menu),
                onTap: () {
                  _scaffoldKey.currentState!.openDrawer();
                },
              ),
            ),
          ),
          // Row(
          //   children: [
          //     const Image(
          //       image: AssetImage('assets/icons/men-logo.jpeg'),
          //       height: 150,
          //       width: 150,
          //     ),
          //     Expanded(
          //       child: Obx(() {
          //         return Wrap(
          //           spacing: 10,
          //           children: [
          //             EmergencyItemCircle(
          //                 title: "ambulance",
          //                 onTap: controller.onEmergencyTypeTap,
          //                 isSelected: controller.alertType.value ==
          //                     "ambulance"),
          //             EmergencyItemCircle(
          //                 title: "firebrigade",
          //                 onTap: controller.onEmergencyTypeTap,
          //                 isSelected: controller.alertType.value ==
          //                     "firebrigade"),
          //             EmergencyItemCircle(
          //                 title: "police",
          //                 onTap: controller.onEmergencyTypeTap,
          //                 isSelected:
          //                 controller.alertType.value == "police"),
          //           ],
          //         );
          //       }),
          //     ),
          //   ],
          // ),
          //Type of Alert
          Align(
            alignment: Alignment.center,
            child: Image(
              image: const AssetImage('assets/icons/men-logo.jpeg'),
              height: SizeConfig.heightMultiplier * 16.105,
              width: SizeConfig.widthMultiplier * 32.46,
              // height: 110,
              // width: 150,
            ),
          ),
          SizedBox(
            height: MediaQuery.of(context).size.height * 0.01,
          ),
          Obx(() {
            return Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                EmergencyItemCircle(
                    title: "ambulance",
                    onTap: (val) {
                      alertType = "ambulance";
                      controller.onEmergencyTypeTap("ambulance");
                    },
                    isSelected: controller.alertType.value == "ambulance"),
                EmergencyItemCircle(
                    title: "firebrigade",
                    onTap: (val) {
                      alertType = "firebrigade";
                      controller.onEmergencyTypeTap("firebrigade");
                    },
                    isSelected: controller.alertType.value == "firebrigade"),
                EmergencyItemCircle(
                    title: "coast guard",
                    onTap: (val) {
                      alertType = "coast guard";
                      controller.onEmergencyTypeTap("coast guard");
                    },
                    isSelected: controller.alertType.value == "coast guard"),
                EmergencyItemCircle(
                    title: "police",
                    onTap: (val) {
                      alertType = "police";
                      controller.onEmergencyTypeTap("police");
                    },
                    isSelected: controller.alertType.value == "police"),
              ],
            );
          }),
          SizedBox(
            height: MediaQuery.of(context).size.height * 0.03,
          ),
          //Type of Alert
          GetBuilder<TransactionAlertController>(
            init: TransactionAlertController(),
            builder: (controller) {
              return Expanded(
                child: Center(
                  child: Stack(
                    children: [
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          //count down of send alert!
                          Listener(
                            onPointerDown: controller.isAlertSent.value ||
                                    myAppUser.isSubscriptionExpired == null ||
                                    myAppUser.isSubscriptionExpired == true
                                ? (d) {}
                                : (details) async {
                                    controller.isAlertSent.value = false;
                                    countdownController?.start();
                                    if (await Vibration.hasVibrator() == true) {
                                      Vibration.vibrate(duration: 6000);
                                    }
                                  },
                            onPointerUp: controller.isAlertSent.value ||
                                    myAppUser.isSubscriptionExpired == null ||
                                    myAppUser.isSubscriptionExpired == true
                                ? (d) {}
                                : (details) {
                                    countdownController?.restart();
                                    countdownController?.pause();
                                  },
                            child: Container(
                              width: MediaQuery.of(context).size.width,
                              padding: const EdgeInsets.only(
                                left: 8,
                                right: 8,
                              ),
                              height: MediaQuery.of(context).size.height * 0.5,
                              child: Column(
                                children: [
                                  GetBuilder<TransactionAlertController>(
                                      builder: (con) {
                                    return con.isAlertSent.value == true
                                        ? const Text(
                                            'Emergency Help Has Been Contacted! \nDon\'t Close App for 5 minutes',
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                              fontSize: 15.6,
                                              fontWeight: FontWeight.w500,
                                            ),
                                          )
                                        : Countdown(
                                            seconds: 6,
                                            controller: countdownController,
                                            build: (BuildContext context,
                                                    double time) =>
                                                Text(
                                              time == 6.0
                                                  ?

                                                  ///todo:da hm esta berta enable ka bia
                                                  myAppUser.isSubscriptionExpired ==
                                                              null ||
                                                          myAppUser
                                                                  .isSubscriptionExpired ==
                                                              true
                                                      ? ""
                                                      : "Hold for 5 Seconds to Send Alert!"
                                                  : "Sending Alert in ${time.seconds.inSeconds}",
                                              style: AppTextStyles.kPrimaryS9W1
                                                  .copyWith(
                                                fontSize: 16,
                                              ),
                                            ),
                                            //   Obx(
                                            // () {
                                            // if (controller.isAlertSent.value) {
                                            //   return Text(
                                            //     "Emergency Help Has Been Contacted!",
                                            //     textAlign: TextAlign.center,
                                            //     style:
                                            //         AppTextStyles.kPrimaryS9W1.copyWith(
                                            //       fontSize: 16,
                                            //     ),
                                            //   );
                                            // }
                                            //   return Text(
                                            //     time == 6.0
                                            //         ? "Hold for 5 Seconds to Send Alert!"
                                            //         : "Sending alert in ${time.seconds.inSeconds}",
                                            //     style: AppTextStyles.kPrimaryS9W1
                                            //         .copyWith(
                                            //       fontSize: 16,
                                            //     ),
                                            //   );
                                            // },
                                            //),
                                            interval: const Duration(
                                                milliseconds: 100),
                                            onFinished: () {
                                              Get.find<
                                                      TransactionAlertController>()
                                                  .startButtonAnimation(
                                                      alertType);
                                            },
                                          );
                                  }),
                                  SizedBox(
                                    height: SizeConfig.heightMultiplier * 0.06,
                                  ),
                                  controller.isAnimating
                                      ? const MENAlertAnimation()
                                      : MenAlertOffContainer(
                                          onPressed: () {
                                            controller.isAlertSent.value =
                                                false;
                                            controller.update();
                                            countdownController?.pause();
                                            countdownController?.restart();
                                          },
                                        ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),

                      /// todo: mara da ba wrasara hm bia esta enable ke
                      Visibility(
                        visible: myAppUser.isSubscriptionExpired == null ||
                            myAppUser.isSubscriptionExpired == false,
                        child: Center(
                          child: SizedBox(
                            height: 210,
                            width: 180,
                            child: GestureDetector(
                              onTap: () {
                                Get.toNamed(Routes.PLANS);
                              },
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Image.asset(
                                    'assets/subscribe_first.png',
                                    fit: BoxFit.contain,
                                    height: 160,
                                    width: 210,
                                  ),
                                  const SizedBox(
                                    height: 3,
                                  ),
                                  const Text(
                                    'Subscribe to Use',
                                    style: TextStyle(
                                      fontWeight: FontWeight.w500,
                                      color: Colors.white,
                                      fontSize: 15,
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 12,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ],
      )),
    );
  }
}

class EmergencyItemCircle extends StatelessWidget {
  final String title;
  final Function(String) onTap;
  final bool isSelected;

  const EmergencyItemCircle(
      {Key? key,
      required this.title,
      required this.onTap,
      required this.isSelected})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      enableFeedback: true,
      splashColor: Colors.transparent,
      highlightColor: Colors.transparent,
      onTap: () => onTap(title),
      child: Column(
        children: [
          Container(
            height: SizeConfig.heightMultiplier * 8.05,
            width: SizeConfig.widthMultiplier * 11.38,
            // height: 55,
            // width: 55,
            padding: EdgeInsets.all(SizeConfig.heightMultiplier * 1.63),
            decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isSelected
                    ? AppColors.lightRed
                    : Colors.grey.withOpacity(0.2)),
            child: Image(
              image: AssetImage(_getCardIcon(title)),
            ),
          ),
          SizedBox(height: SizeConfig.heightMultiplier * 0.3),
          Text(
            _getTitle(title),
            style: TextStyle(
              fontWeight: FontWeight.w400,
              fontSize: 11,
              color: isSelected ? AppColors.lightRed : Colors.grey,
            ),
          ),
        ],
      ),
    );
  }

  String _getCardIcon(String type) {
    type = type.toLowerCase();
    if (type == "firebrigade") {
      return 'assets/icons/fire-truck.png';
    } else if (type == "police") {
      return 'assets/icons/police-car.png';
    } else if (type == "coast guard") {
      return 'assets/icons/coast_guard.png';
    } else {
      return 'assets/icons/ambulance.png';
    }
  }

  String _getTitle(String type) {
    type = type.toLowerCase();
    if (type == "firebrigade") {
      return "Fire Dept";
    } else if (type == "police") {
      return "Police";
    } else if (type == "coast guard") {
      return "Coast Guard";
    } else {
      return "Ambulance";
    }
  }
}
